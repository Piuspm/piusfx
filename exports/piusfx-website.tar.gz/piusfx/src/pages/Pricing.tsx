import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, ArrowRight } from "lucide-react";

const plans = [
  {
    name: "Signals VIP",
    desc: "For traders who want high-probability setups delivered to their phone.",
    price: 49,
    period: "month",
    features: [
      "3-7 High Probability Setups/Week",
      "Exact Entry, SL & Multiple TPs",
      "Trade Management Updates",
      "Weekly Market Outlook Video",
      "VIP Community Access",
      "24/7 Support"
    ],
    popular: true,
    cta: "Join VIP Signals"
  },
  {
    name: "Mastery Course",
    desc: "The complete A-Z framework to become an independent, profitable trader.",
    price: 299,
    period: "lifetime",
    features: [
      "50+ Video Lessons (Beginner to Pro)",
      "Institutional Price Action Model",
      "Liquidity & Market Structure Concepts",
      "Risk Management Calculator",
      "Trading Psychology Guide",
      "Lifetime Updates"
    ],
    popular: false,
    cta: "Enroll Now"
  },
  {
    name: "1-on-1 Mentorship",
    desc: "Direct access to Pius for accelerated learning and custom strategy building.",
    price: 999,
    period: "3 months",
    features: [
      "Everything in Course & Signals",
      "Bi-Weekly 1-on-1 Zoom Calls",
      "Daily Trade Reviews via Telegram",
      "Custom Trading Plan Development",
      "Funding Challenge Prep",
      "Direct Priority Access"
    ],
    popular: false,
    cta: "Apply for Mentorship"
  }
];

export default function Pricing() {
  return (
    <div className="w-full pt-32 pb-24 min-h-screen relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl md:text-6xl font-display font-bold mb-6">Invest in Your Edge</h1>
            <p className="text-lg text-muted-foreground">
              Stop paying the market tuition. Choose the path that fits your goals and accelerate your journey to consistent profitability.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`relative ${plan.popular ? 'md:-translate-y-4' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider z-10">
                  Most Popular
                </div>
              )}
              <Card className={`h-full bg-card/60 backdrop-blur-sm relative overflow-hidden transition-all duration-300 hover:border-primary/50 ${plan.popular ? 'border-primary shadow-[0_0_30px_rgba(255,215,0,0.15)]' : 'border-white/10'}`}>
                {plan.popular && <div className="absolute inset-0 bg-gradient-to-b from-primary/10 to-transparent pointer-events-none" />}
                
                <CardContent className="p-8 relative z-10 flex flex-col h-full">
                  <h3 className="text-2xl font-bold mb-2 text-white">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground mb-6 min-h-[40px]">{plan.desc}</p>
                  
                  <div className="mb-8 pb-8 border-b border-white/10">
                    <span className="text-5xl font-display font-bold text-white">${plan.price}</span>
                    <span className="text-muted-foreground ml-2">/{plan.period}</span>
                  </div>
                  
                  <ul className="space-y-4 mb-8 flex-grow">
                    {plan.features.map((feature, j) => (
                      <li key={j} className="flex items-start">
                        <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mr-3 mt-0.5" />
                        <span className="text-muted-foreground text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full h-12 text-base ${plan.popular ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-white/5 hover:bg-white/10 text-white'}`}
                  >
                    {plan.cta}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <p className="text-muted-foreground mb-4">Not sure which plan is right for you?</p>
          <Link href="/contact">
            <Button variant="link" className="text-primary hover:text-primary/80">
              Contact our support team <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
